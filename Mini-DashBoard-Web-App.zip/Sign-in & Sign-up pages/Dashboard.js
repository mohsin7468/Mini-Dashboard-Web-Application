
$(document).ready(function () {

    const tableBody = $('#myTable tbody'); // Select the table body
    tableBody.empty();
    //event.defaultPrevented();
    
    for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        const remaining_data = JSON.parse(localStorage.getItem(key));


        const row = `<tr class="HoverHighlight">                       
                        <td>${key}</td>
                        <td>${remaining_data.email}</td>
                        <td>${remaining_data.DOB}</td>
                        <td>${remaining_data.username}</td>
                        <td>${remaining_data.pass}</td>
                        <td>${remaining_data.confirmpassword}</td>
                        <td>${remaining_data.contactnumber}</td>       
                        <td>${remaining_data.comments}</td>
                        <td><button class="btn btn-outline-danger" onClick="deleteRow('${key}')" >Delete Record</button></td>
                    </tr>`;
        tableBody.append(row);
      
    }
    $('#myTable').DataTable();
    
   

});

function deleteRow(name){

    const key = name;
    localStorage.removeItem(key);
    const tableBody = $('#myTable tbody');
    tableBody.find(`tr[data-key="${key}"]`).remove();
    alert(key + "record Deleted");
    location.reload();
    //Repopulating the table after deletion
    // for (let i = 0; i < localStorage.length; i++) {
    //     const key = localStorage.key(i);
    //     const remaining_data = JSON.parse(localStorage.getItem(key));
    //     const row = `<tr class="HoverHighlight">                       
    //                     <td>${key}</td>
    //                     <td>${remaining_data.email}</td>
    //                     <td>${remaining_data.DOB}</td>
    //                     <td>${remaining_data.username}</td>
    //                     <td>${remaining_data.pass}</td>
    //                     <td>${remaining_data.confirmpassword}</td>
    //                     <td>${remaining_data.contactnumber}</td>       
    //                     <td>${remaining_data.comments}</td>
    //                     <td><button class="btn btn-outline-danger" onClick="deleteRow('${key}')" >Delete Record</button></td>
    //                 </tr>`;
    //     tableBody.append(row);
      
    // }
    $('#myTable').DataTable();

}

