

function validateID_Pass() {
    event.preventDefault();
    let name = document.getElementById('Identification').value;
    let password = document.getElementById('password').value;

    //console.log(localStorage.getItem(name));
    if (name == null || name == "") {
        alert("Enter your name First");
    }
    else {
        var Verfied_Name = check();
    }

    function check() {

        for (let i = 0; i < localStorage.length; i++) {
            console.log("Loop started");
            if (name == localStorage.key(i)) {

                const remaining_data = JSON.parse(localStorage.getItem(name));
                if (password == remaining_data.confirmpassword) {
                    alert("Welcome to Dashboard " + name);
                    window.location.href = "Dashboard.html";
                }
                else if (password != remaining_data.confirmpassword) {
                    alert("Incorrect Password.");
                }
                return name;

            }
        }
    }


    if (name != Verfied_Name) {
        alert("Incorrect credentials");

    }
    
}