// $(document).ready(function(){

//     $('#btn').click(function(){

//        var val = document.getElementById('input').value;

//        console.log(val);
//     });
// });

$(document).ready(function () {
    $('#signup').click(function (event) {

        //  event.preventDefault();
        let Full_Name = document.getElementById('fullName').value;
        let Email = document.getElementById('email').value;
        let Date_of_Birth = document.getElementById('dob').value;
        let User_Name = document.getElementById('userN').value;
        let Password = document.getElementById('pass').value;
        let Confirm_password = document.getElementById('ConfirmPass').value;
        let Contact_no = document.getElementById('contactN').value;
        let Remarks = document.getElementById('textbox').value;

        if (Full_Name == '' || Email == '' || Date_of_Birth == '' ||  User_Name== '' ||
            Password == '' || Confirm_password == '' || Contact_no == '') {

            alert("Required fields cannot be empty!");
            event.preventDefault();
        }

        else{

            let formDataObj = {
                email: Email,
                DOB: Date_of_Birth,
                username: User_Name,
                pass: Password,
                confirmpassword: Confirm_password,
                contactnumber: Contact_no,
                comments: Remarks
            };

            let formDataObjString = JSON.stringify(formDataObj);
            localStorage.setItem(Full_Name, formDataObjString);
            alert("Dear " + Full_Name + " Your information has been stored successfully.");
        }

    });
});
